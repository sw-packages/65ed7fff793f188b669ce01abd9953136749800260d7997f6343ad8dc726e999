#include <list>
int main(int, char* [])
{
  std::list<int>();
  return 0;
}
